# Land 07 - Encontrando soluções

## 💻 Sobre o desafio

sse desafio **tem apenas 1 parte. Por isso capriche, hein!**

Você deverá revisar seus projetos do Explorer e anotar alguma dúvida que ainda não entendeu. **Com essa pergunta registrada, crie um tópico no fórum do Explorer**, seguindo o modelo que o Rodrigo mostrou na aula! Se já houver um tópico criado sobre o tema, leia as respostas propostas e teste as sugestões! Lembre-se de dar um upvote e comentar, se deu certo para você.

📢 **Atenção!** Não esqueça de incluir todas as informações que são importantes e foram informadas nas aulas. Se precisar, abra a documentação do fórum: [Como criar um tópico ideal](https://www.notion.so/Como-criar-um-t-pico-ideal-408faa68bebc4f9590711ee935c9cac9)

## Tags

[![html](https://camo.githubusercontent.com/fb8d8c63bd6142333a82e82c2e255f2cbdeb008bf56c96464ded3c032c0032a6/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f48746d6c352d3035313232413f7374796c653d666c6174266c6f676f3d68746d6c35)](https://developer.mozilla.org/en-US/docs/Web/HTML)
[![css](https://camo.githubusercontent.com/12031019e79c64fd983746f4cd893a528603b8b76e226fcaf970e6761c970a3e/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f437373332d3035313232413f7374796c653d666c6174266c6f676f3d63737333)](https://developer.mozilla.org/en-US/docs/Web/CSS)
[![javascript](https://camo.githubusercontent.com/81e2b21363c97f16147a7e90b2cb977d4e79e9287be2406b3fb634cec8e65681/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f4a6176617363726970742d3035313232413f7374796c653d666c6174266c6f676f3d6a617661736372697074)](https://developer.mozilla.org/en-US/docs/Web/javascript)
[![github](https://camo.githubusercontent.com/3a4b8be7910bd9b32a8d5dbf796a49ed2c12607b64fa3f03dfbb34c315fc58ab/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f2d4769744875622d3138313731373f7374796c653d666c6174266c6f676f3d676974687562)](https://developer.mozilla.org/en-US/docs/Learn/Tools_and_testing/GitHub)
